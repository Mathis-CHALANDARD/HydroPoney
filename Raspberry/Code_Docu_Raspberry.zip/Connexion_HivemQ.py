# Projet Hydroponey, code servant à recuperer les données venant du Broker HivemQ et l'enregistrer dans influxdb.
# David Mamina
# 12-05-2023

from influxdb import InfluxDBClient
import paho.mqtt.client as mqtt
import json

# Configuration des informations de connexion
broker_address = "broker.hivemq.com"
broker_port = 1883
broker_url = "tcp://broker.hivemq.com:1883"
topic = "hydroponey/arduino/push"
username = "hydroponey"
password = "motdepassesupersecure"

# Configuration des informations de connexion InfluxDB
influxdb_host = "localhost"
influxdb_port = 8086
influxdb_user = "admin"
influxdb_password = "Bonjour1"
influxdb_database = "hydroponie"

# Fonction pour se connecter à InfluxDB
def influxdb_connect():
    client = InfluxDBClient(host=influxdb_host, port=influxdb_port, username=influxdb_user, password=influxdb_password)
    client.switch_database(influxdb_database)
    return client

# Fonction appelée lors de la connexion au broker MQTT
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    client.subscribe(topic)

# Fonction pour traiter les messages MQTT reçus
def on_message(client, userdata, message):
    json_body = [
        {
            "measurement": "hydro",
            "tags": {
                "topic": message.topic
            },
            "fields": {
                 "payload": float(message.payload.decode())
                 }
        }
    ]
    influxdb_client.write_points(json_body)

influxdb_client = influxdb_connect()

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.username_pw_set(username, password)
client.connect(broker_address, broker_port, 60)

client.loop_forever()
